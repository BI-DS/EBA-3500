import pandas as pd
weather = pd.read_csv("weatherAUS.csv")
weather = weather.dropna()
weather["RainToday"] = (weather["RainToday"] == "Yes") * 1
weather["RainTomorrow"] = (weather["RainTomorrow"] == "Yes") * 1
weather = weather.drop(columns="Date")

weather.shape

weather.WindDir3pm
weather.WindDir9am
weather.WindGustDir

from collections import Counter
Counter(weather.Location)

set(weather.WindDir3pm).union(set(weather.WindDir9am)).union(set(weather.WindGustDir))
import statsmodels.formula.api as smf
from scipy.special import expit
model = smf.logit("RainTomorrow ~ Location - 1", data = weather).fit()
probs = expit(model.params)
probs[0] # Probability of AliceSprings.
names = list(probs.index)
(names[probs.argmax()], probs.max())
(names[probs.argmin()], probs.min())

expit(model.conf_int())

model = smf.logit("RainTomorrow ~ RainToday", data = weather).fit()


model = smf.logit("RainTomorrow ~ Location * RainToday", data = weather).fit()

smf.logit("RainTomorrow ~ Date * Location", data = weather).fit()

import statsmodels.formula.api as smf

model = smf.logit("RainTomorrow ~ C(Location)", data = weather).fit()

model = smf.logit("RainTomorrow ~ C(Location)+ RainToday", data = weather).fit()

model = smf.logit("RainTomorrow ~ C(Location)+ C(Location) * RainToday", data = weather).fit()


all_columns = " + ".join(set(weather.columns.tolist()) - {"RainTomorrow"})

model = smf.logit("RainTomorrow ~ " + all_columns, data = weather).fit()

def all_columns(data, name):
  return name + " ~ " + " + ".join(set(data.columns.tolist()) - {name})

smf.logit(all_columns(weather, "RainTomorrow"), data = weather).fit()


"np.log(wages) ~ age + education * gender"




import statsmodels.api as sm
smf.glm("RainTomorrow ~ C(Location)+ RainToday", data = weather, family = sm.families.Binomial((sm.families.links.CLogLog()))).fit()


import sklearn.preprocessing as skp
skp.normalize(weather)

import seaborn as sns
import statsmodels.api as sm
import statsmodels.formula.api as smf
import numpy as np
import matplotlib.pyplot as plt
cpssw8 = sm.datasets.get_rdataset("CPSSW8", "AER").data

sns.pairplot(cpssw8)


model = smf.ols("np.log(earnings) ~ gender + age + education", data = cpssw8).fit()

sm.qqplot(model.resid, line = '45')
plt.show()
plt.clf()

model = smf.ols("np.log(earnings) ~ gender * education + age", data = cpssw8).fit()

model.predict({"gender": "female", "age": 40, "education": 20})
model.predict({"gender": "male", "age": 40, "education": 20})

plt.scatter(model.fittedvalues, model.resid, s = 0.6)
plt.show()
plt.clf()

plt.scatter(cpssw8.age, np.log(cpssw8.earnings), s = 0.6)
plt.show()
plt.clf()


model = smf.ols("np.log(earnings) ~ gender * education + age", data = cpssw8).fit()

model.summary()

model = smf.ols("np.log(earnings) ~ gender * education + age + region", data = cpssw8).fit()


model = smf.ols("np.log(earnings) ~ gender * education + age + region * education", data = cpssw8).fit()

"np.log(wages) ~ age + education + gender"
