import statsmodels.api as sm
import numpy as np
#cpssw8 = sm.datasets.get_rdataset("CPSSW8", "AER").data

set(cpssw8.region)

smf.ols("np.log(earnings) ~ region + gender", data = cpssw8).fit().summary()

formula = "np.log(earnings) ~ age + education + gender + region * education"

model = smf.ols(formula, data = cpssw8).fit()

sm.stats.anova_lm(model, typ=3) 

model = smf.ols("np.log(earnings) ~ age + education * gender", data = cpssw8).fit()

sm.qqplot(model.resid, line = "45")
